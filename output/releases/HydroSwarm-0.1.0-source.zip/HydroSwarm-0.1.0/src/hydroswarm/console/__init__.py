"""Local-only operator console."""

